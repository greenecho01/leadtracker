export default async function handler(req, res) {
  const { postcode, page } = req.query;

  const url = `https://epc.opendatacommunities.org/api/v1/properties?postcode=${encodeURIComponent(
    postcode
  )}&page=${page || 1}&pagesize=25`;

  try {
    const result = await fetch(url, {
      headers: {
        Authorization: "Token 0bc003a613ee57ac2857ad54b6de2c2e5990366e",
      },
    });

    const data = await result.json();
    res.status(200).json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch EPC data" });
  }
}
