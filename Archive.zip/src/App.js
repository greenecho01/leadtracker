import React, { useState, useEffect } from "react";

const API_TOKEN = "0bc003a613ee57ac2857ad54b6de2c2e5990366e";
const API_URL = "/api/epc";


const EPC_RATINGS = ["D", "E", "F", "G"];
const GAS_OPTIONS = ["gas", "off-gas"];

function App() {
  const [postcode, setPostcode] = useState("");
  const [loading, setLoading] = useState(false);
  const [properties, setProperties] = useState([]);
  const [filters, setFilters] = useState({
    epcRatings: new Set(EPC_RATINGS),
    gasStatus: new Set(GAS_OPTIONS),
  });
  const [progress, setProgress] = useState({});

  useEffect(() => {
    const saved = localStorage.getItem("leadgen-progress");
    if (saved) setProgress(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("leadgen-progress", JSON.stringify(progress));
  }, [progress]);

  function toggleFilter(type, value) {
    setFilters((f) => {
      const newSet = new Set(f[type]);
      if (newSet.has(value)) newSet.delete(value);
      else newSet.add(value);
      return { ...f, [type]: newSet };
    });
  }

  async function fetchProperties(postcode) {
    setLoading(true);
    let allProps = [];
    let page = 1;
    let keepFetching = true;

    while (keepFetching && allProps.length < 100) {
      const url = `${API_URL}?postcode=${encodeURIComponent(
        postcode
      )}&page=${page}&pagesize=25`;

      try {
        const res = await fetch(url, {
          headers: { Authorization: `Token ${API_TOKEN}` },
        });
        if (!res.ok) {
          alert("Error fetching EPC data");
          setLoading(false);
          return;
        }
        const data = await res.json();

        if (data?.rows?.length) {
          allProps = allProps.concat(data.rows);
          page++;
          if (page > data.pagination.totalPages) keepFetching = false;
        } else {
          keepFetching = false;
        }
      } catch (e) {
        alert("Fetch error: " + e.message);
        setLoading(false);
        return;
      }
    }
    setProperties(allProps.slice(0, 100));
    setLoading(false);
  }

  const filteredProps = properties.filter((p) => {
    const rating = p["current-energy-rating"]?.toUpperCase() || "";
    if (!filters.epcRatings.has(rating)) return false;

    const mainFuel = (p["main-fuel"] || p["main-fuel-type"] || "").toLowerCase();
    const isGas = mainFuel.includes("gas");
    if (isGas && !filters.gasStatus.has("gas")) return false;
    if (!isGas && !filters.gasStatus.has("off-gas")) return false;

    return true;
  });

  function updateProgress(propertyId, field, value) {
    setProgress((p) => {
      const old = p[propertyId] || {};
      return { ...p, [propertyId]: { ...old, [field]: value } };
    });
  }

  return (
    <div
      style={{
        maxWidth: 900,
        margin: "auto",
        padding: 16,
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h1>Green Echo Lead Gen App</h1>

      <div>
        <label>
          Enter postcode:{" "}
          <input
            type="text"
            value={postcode}
            onChange={(e) => setPostcode(e.target.value.toUpperCase())}
            placeholder="e.g. NG9 2BT"
            style={{ textTransform: "uppercase" }}
          />
        </label>
        <button
          onClick={() => fetchProperties(postcode)}
          disabled={loading || !postcode.trim()}
          style={{ marginLeft: 8 }}
        >
          {loading ? "Loading..." : "Search"}
        </button>
      </div>

      <div style={{ marginTop: 16 }}>
        <h3>Filters</h3>
        <div>
          <strong>EPC Rating:</strong>{" "}
          {EPC_RATINGS.map((r) => (
            <label key={r} style={{ marginRight: 8 }}>
              <input
                type="checkbox"
                checked={filters.epcRatings.has(r)}
                onChange={() => toggleFilter("epcRatings", r)}
              />{" "}
              {r}
            </label>
          ))}
        </div>
        <div style={{ marginTop: 8 }}>
          <strong>Gas Status:</strong>{" "}
          {GAS_OPTIONS.map((g) => (
            <label key={g} style={{ marginRight: 8 }}>
              <input
                type="checkbox"
                checked={filters.gasStatus.has(g)}
                onChange={() => toggleFilter("gasStatus", g)}
              />{" "}
              {g}
            </label>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 24 }}>
        <h3>
          Properties ({filteredProps.length} / {properties.length} fetched)
        </h3>
        {filteredProps.length === 0 && <p>No properties found for these filters.</p>}

        {filteredProps.map((p) => {
          const pid = p["property-uid"];
          const prog = progress[pid] || {};

          return (
            <div
              key={pid}
              style={{
                border: "1px solid #ccc",
                padding: 12,
                marginBottom: 8,
                borderRadius: 4,
              }}
            >
              <div>
                <strong>
                  {p.address1}, {p.address2 ? p.address2 + ", " : ""}
                  {p.postcode}
                </strong>{" "}
                | EPC: {p["current-energy-rating"] || "N/A"} | Fuel:{" "}
                {p["main-fuel"] || p["main-fuel-type"] || "Unknown"}
              </div>

              <div
                style={{
                  marginTop: 8,
                  display: "flex",
                  gap: 16,
                  flexWrap: "wrap",
                }}
              >
                {[
                  "contacted",
                  "notAtHome",
                  "qualified",
                  "signed",
                  "evidence",
                ].map((field) => (
                  <label key={field}>
                    <input
                      type="checkbox"
                      checked={!!prog[field]}
                      onChange={(e) =>
                        updateProgress(pid, field, e.target.checked)
                      }
                    />{" "}
                    {field
                      .replace(/([A-Z])/g, " $1")
                      .replace(/^./, (str) => str.toUpperCase())}
                  </label>
                ))}
              </div>

              <div style={{ marginTop: 8 }}>
                <label>
                  Notes:{" "}
                  <textarea
                    value={prog.notes || ""}
                    onChange={(e) => updateProgress(pid, "notes", e.target.value)}
                    rows={2}
                    cols={50}
                    placeholder="Add notes here..."
                  />
                </label>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default App;
